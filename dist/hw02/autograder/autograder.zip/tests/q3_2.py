test = {   'name': 'q3_2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> np.allclose(products, np.array([6594, 663168, 6660320568, -39250]))\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
