test = {   'name': 'q3_3',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> np.allclose(correct_products, np.array([66234, 6661248, 66900162648, -394250]))\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
