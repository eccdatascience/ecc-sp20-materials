test = {   'name': 'q4_1',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> largest_population_change == 87515824\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
