test = {   'name': 'q5_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 15 <= average_error <= 25\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(average_error, 20.520295202952031)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
