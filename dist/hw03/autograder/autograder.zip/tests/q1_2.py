test = {   'name': 'q1_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> by_nei.take(0).column(0).item(0) == '2009-10-01'\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> by_nei_pter.take(0).column(0).item(0) == '2009-10-01'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
