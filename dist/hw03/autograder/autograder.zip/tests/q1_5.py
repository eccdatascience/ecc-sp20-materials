test = {   'name': 'q1_5',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> by_pter.take(0).column(0).item(0) == '2009-07-01'\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
