test = {   'name': 'q2_2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> 0 < movers <= 52\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> movers == 9\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
