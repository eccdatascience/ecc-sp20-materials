test = {   'name': 'q2_7',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> type(assoc) is bool\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> assoc == True\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
