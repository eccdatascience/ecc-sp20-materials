test = {   'name': 'q4_4',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> 1 <= manila_median_bin <= 4\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> manila_median_bin == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
