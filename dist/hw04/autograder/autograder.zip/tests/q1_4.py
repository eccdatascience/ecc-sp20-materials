test = {   'name': 'q1_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> # Number of columns should be 2;\n>>> california_burritos.num_columns == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Number of rows should be 46;\n>>> california_burritos.num_rows == 46\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> california_burritos.take(40).column(0).item(0) == 'Taco Stand Encinitas'\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
