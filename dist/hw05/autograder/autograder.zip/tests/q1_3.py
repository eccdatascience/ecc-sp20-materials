test = {   'name': 'q1_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> 'did_cal_win' in globals()\nTrue", 'hidden': False, 'locked': False},
                                   {'code': '>>> did_cal_win(final_scores.row(1)) == True\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
