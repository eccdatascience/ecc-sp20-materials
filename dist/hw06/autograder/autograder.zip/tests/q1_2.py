test = {   'name': 'q1_2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> five_or_less in [1,2,3]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> five_or_less == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
