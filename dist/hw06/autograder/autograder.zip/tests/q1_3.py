test = {   'name': 'q1_3',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> lottery in [1,2,3]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> lottery == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
