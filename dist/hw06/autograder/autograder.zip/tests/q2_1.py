test = {   'name': 'q2_1',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> round(data_chance, 11) == 1.09e-09\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
