test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> 0 <= prob_781 <= 1\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> np.round(prob_781, 9) == 1.562e-6\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
