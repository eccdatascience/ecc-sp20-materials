test = {   'name': 'q1_14',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> 0 <= p_value < 1\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> visited_observed_value == 4\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
