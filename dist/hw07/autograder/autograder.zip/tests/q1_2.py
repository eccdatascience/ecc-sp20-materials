test = {   'name': 'q1_2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> 0 <= prob_yanay_num <= 1\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> prob_yanay_num == 1e-07\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
