test = {   'name': 'q1_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(reasonable_test_statistics) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(reasonable_test_statistics) >0\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(reasonable_test_statistics) == set([1, 4, 5])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
