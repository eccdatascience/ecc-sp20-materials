test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> N == "parameter" or N == "statistic"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> N_estimate == "parameter" or N_estimate == "statistic"\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> N == "parameter" and N_estimate == "statistic"\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
