test = {   'name': 'q2_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> min(true_statements) >= 1 and max(true_statements) <= 6\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(true_statements) == set([1,2,5,6])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
