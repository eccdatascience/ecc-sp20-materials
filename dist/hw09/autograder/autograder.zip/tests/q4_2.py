test = {   'name': 'q4_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> len(resample_positive_percentages) == 5000\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> abs(np.mean(resample_positive_percentages) - 74) < 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
