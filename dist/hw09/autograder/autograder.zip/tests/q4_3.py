test = {   'name': 'q4_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 1 <= initial_sample_mean_distribution <= 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> initial_sample_mean_distribution == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
