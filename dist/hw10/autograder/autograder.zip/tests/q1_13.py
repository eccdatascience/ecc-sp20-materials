test = {   'name': 'q1_13',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 5 < rmse_example < 10\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(rmse_example, 3) == 7.612\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
