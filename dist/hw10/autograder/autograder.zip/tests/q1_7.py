test = {   'name': 'q1_7',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> # The returned array should be of length 2;\n>>> len(parameters) == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.allclose(parameters, [1.07113964, -6.45428385])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
