test = {   'name': 'q2_3',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> np.round(possibilities_table.column("Formula SD").item(4),3) == 0.196\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
