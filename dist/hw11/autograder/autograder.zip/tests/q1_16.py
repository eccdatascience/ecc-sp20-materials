test = {   'name': 'q1_16',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(greatest_career_length_residual) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> greatest_career_length_residual == 'Tom Brady'\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
