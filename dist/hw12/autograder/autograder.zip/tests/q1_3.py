test = {   'name': 'q1_3',
    'points': 1,
    'suites': [{'cases': [{'code': ">>> sorted(features) == ['latitude', 'longitude']\nTrue", 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
