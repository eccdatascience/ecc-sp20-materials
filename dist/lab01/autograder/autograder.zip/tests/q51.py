test = {   'name': 'q51',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> assert round(paola_distance_from_average_m, 5) == 0.072\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
