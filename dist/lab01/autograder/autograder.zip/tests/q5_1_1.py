test = {   'name': 'q5_1_1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> assert round(min_height_difference, 5) == 0.04\n', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
