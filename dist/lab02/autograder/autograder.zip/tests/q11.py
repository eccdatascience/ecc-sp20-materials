test = {'name': 'q11', 'points': 1, 'suites': [{'cases': [{'code': '>>> new_year == 2020\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
