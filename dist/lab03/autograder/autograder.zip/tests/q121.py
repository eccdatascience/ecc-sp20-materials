test = {   'name': 'q121',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> abs(difference) == 30 or round(abs(difference), 1) == 30.0\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
