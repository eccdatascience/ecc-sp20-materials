test = {   'name': 'q131',
    'points': None,
    'suites': [{'cases': [{'code': '>>> sentence_length == 896\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
