test = {   'name': 'q211',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(interesting_numbers) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(interesting_numbers) == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> all(interesting_numbers == np.array([0, 1, -1, math.pi, math.e]))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
