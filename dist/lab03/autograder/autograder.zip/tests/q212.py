test = {   'name': 'q212',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(hello_world_components) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(interesting_numbers) == 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> all(hello_world_components == np.array(["Hello", ",", " ", "world", "!"]))\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
