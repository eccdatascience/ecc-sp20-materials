test = {   'name': 'q221',
    'points': None,
    'suites': [{'cases': [{'code': '>>> population_1973 == 3942096442\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
