test = {   'name': 'q22',
    'points': None,
    'suites': [{'cases': [{'code': ">>> str(mark_hurd_pay_string) == '$53.25 '\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
