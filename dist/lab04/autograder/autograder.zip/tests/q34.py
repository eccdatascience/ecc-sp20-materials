test = {   'name': 'q34',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> # Checking length of cash_proportion;\n>>> len(cash_proportion) == 102\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> import math;\n>>> math.isclose(cash_proportion.item(0), 0.01784038, rel_tol = .001)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
