test = {   'name': 'q23',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> 1000 <= total_score <= 10000\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
