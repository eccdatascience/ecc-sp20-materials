test = {   'name': 'q33',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> len(convenience_stats) == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(float(convenience_stats[0]), 2) == 20.36\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(float(convenience_stats[1]), 2) == 2383533.82\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
