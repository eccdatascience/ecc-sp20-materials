test = {   'name': 'q1_6',
    'points': None,
    'suites': [{'cases': [{'code': '>>> int(round(observed_statistic,2)) == 6\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
