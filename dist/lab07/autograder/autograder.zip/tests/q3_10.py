test = {   'name': 'q3_10',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> test_stat = round(simulate_and_test_statistic(change_in_death_rates, "Death Penalty", "Murder Rate"), 3);\n>>> -5 < test_stat < 5\nTrue',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
