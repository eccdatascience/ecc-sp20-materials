test = {   'name': 'q2_5',
    'points': None,
    'suites': [{'cases': [{'code': '>>> SD_of_sample_means == 3\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
