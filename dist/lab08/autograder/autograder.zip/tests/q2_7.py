test = {'name': 'q2_7', 'points': None, 'suites': [{'cases': [{'code': '>>> q2_7 == 1\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
