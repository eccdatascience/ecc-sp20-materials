test = {   'name': 'q1_6',
    'points': None,
    'suites': [{'cases': [{'code': '>>> "%.2f" % round(r,2)\n\'0.90\'', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
