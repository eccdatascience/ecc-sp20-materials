test = {   'name': 'q3_3',
    'points': None,
    'suites': [{'cases': [{'code': '>>> abs(sum(faithful_residuals.column(3))) <= 1e-8\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
