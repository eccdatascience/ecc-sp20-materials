test = {   'name': 'q5_1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> np.allclose([below_3_r, above_3_r], [0.290189526493, 0.372782225571])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> [below_3.num_rows, above_3.num_rows]\n[97, 175]', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
