test = {   'name': 'q5_2',
    'points': None,
    'suites': [   {   'cases': [   {   'code': '>>> np.allclose([wait_below_3(1), wait_below_3(3), wait_above_3(3), wait_above_3(6)], [47.902151605742517, 60.603197182023813, 72.965413990538366, '
                                               '89.281859197449506])\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
