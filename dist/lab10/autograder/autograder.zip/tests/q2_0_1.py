test = {   'name': 'q2_0_1',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> np.isclose(probability_large_shiny, 4/13)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
