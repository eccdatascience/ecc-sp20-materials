test = {   'name': 'q2_1_2',
    'points': None,
    'suites': [{'cases': [{'code': '>>> np.isclose(probability_large_given_shiny, 4/10)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
