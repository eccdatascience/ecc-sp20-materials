test = {   'name': 'q3_1_1',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> cancer\ncancer status | negative | positive\nhealthy       | 9702     | 198\nsick          | 10       | 90', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
