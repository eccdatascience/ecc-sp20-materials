test = {   'name': 'q1_12_0',
    'points': 0,
    'suites': [   {   'cases': [   {'code': '>>> pop_for_year(1972) == 3345978384\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> pop_for_year(1989) == 4567880153\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> pop_for_year(2002) == 5501335945\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
