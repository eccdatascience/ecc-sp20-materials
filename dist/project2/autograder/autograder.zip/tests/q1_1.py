test = {   'name': 'q1_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(all_unique_causes) in [np.ndarray, list]\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> sorted(all_unique_causes) == ['Accidents', 'Cancer', 'Heart Disease', 'Influenza and Pneumonia', 'Stroke']\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
