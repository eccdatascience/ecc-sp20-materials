test = {   'name': 'q1_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> all(disease_trend_explanation >= 1) and all(disease_trend_explanation <=6)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(disease_trend_explanation) == set([1, 3, 5, 6])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
