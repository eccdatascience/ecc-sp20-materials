test = {   'name': 'q2_1_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(diabetes_statistic()) in set([float, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.random.seed(0);\n>>> np.isclose(round(diabetes_statistic(), 5) - 0.00189, 0)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
