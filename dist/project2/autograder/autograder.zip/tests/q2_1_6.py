test = {   'name': 'q2_1_6',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(framingham_diabetes_explanations) in [np.ndarray]\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sorted(framingham_diabetes_explanations) == make_array(1, 2, 3) \narray([ True,  True,  True], dtype=bool)', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
