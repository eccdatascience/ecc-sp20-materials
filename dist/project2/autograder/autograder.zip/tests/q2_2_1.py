test = {   'name': 'q2_2_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> (ab_reasonable == True) or (ab_reasonable == False)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> ab_reasonable == True\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
