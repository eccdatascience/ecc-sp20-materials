test = {   'name': 'q2_2_5',
    'points': 1,
    'suites': [{'cases': [{'code': '>>> len(framingham_simulated_stats) == 1000\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
