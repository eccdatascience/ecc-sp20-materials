test = {   'name': 'q3_1_1',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # Make sure your array only contains the integers that correspond;\n'
                                               ">>> # to the correct options, you don't need to calculate each value;\n"
                                               '>>> sum(nhs_true_statements % 1) == 0\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> min(nhs_true_statements) >= 1 and max(nhs_true_statements <= 6)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(nhs_true_statements) == set([3, 4, 5])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
