test = {   'name': 'q3_1_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(relative_risk(NHS)) in set([float, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(round(float(relative_risk(NHS)), 3) - 0.474, 0)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
