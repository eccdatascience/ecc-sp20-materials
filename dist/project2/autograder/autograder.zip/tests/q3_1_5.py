test = {   'name': 'q3_1_5',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 0 < min(bootstrap_rrs) <= max(bootstrap_rrs) < 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.random.seed(123);\n>>> np.isclose(round(one_bootstrap_rr(), 3), 0.451)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
