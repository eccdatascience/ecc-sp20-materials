test = {   'name': 'q3_1_7',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> # Remember to assign ci_statements to a list!;\n>>> type(ci_statements) in set([np.ndarray])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(ci_statements) == set([2, 3])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
