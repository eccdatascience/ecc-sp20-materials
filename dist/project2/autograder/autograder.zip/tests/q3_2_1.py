test = {   'name': 'q3_2_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(good_ts) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(good_ts) == set([1, 3])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
