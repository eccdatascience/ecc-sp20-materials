test = {   'name': 'q3_2_2',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(observed_HERS_test_statistic) in set([float, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(float(observed_HERS_test_statistic), 4) == 0.0026\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
