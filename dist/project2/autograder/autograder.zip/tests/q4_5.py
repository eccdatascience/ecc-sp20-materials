test = {   'name': 'q4_5',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> summed_mn_hazard_data.num_rows == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(summed_mn_hazard_data.labels) == 4\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> summed_mn_hazard_data.column(1).item(0) == 222 and summed_mn_hazard_data.column(1).item(1) == 245\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
