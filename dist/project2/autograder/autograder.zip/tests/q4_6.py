test = {   'name': 'q4_6',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(death_rate_observed_statistic) in set([float, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(round(death_rate_observed_statistic, 5), 0.00544)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
