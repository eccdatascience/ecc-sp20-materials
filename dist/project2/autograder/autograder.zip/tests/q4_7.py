test = {   'name': 'q4_7',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(our_p_value) in set([float, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 < our_p_value < 1\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
