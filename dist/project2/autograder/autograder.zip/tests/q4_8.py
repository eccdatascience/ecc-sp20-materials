test = {   'name': 'q4_8',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> reject_null in make_array(True, False)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> reject_null == (our_p_value <= 0.05)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
