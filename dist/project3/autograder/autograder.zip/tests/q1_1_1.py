test = {   'name': 'q1_1_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> len(stemmed_message) < len('message')\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> stemmed_message == 'veget'\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
