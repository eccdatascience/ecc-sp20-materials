test = {   'name': 'q1_1_2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> type(most_stem) == str\nTrue', 'hidden': False, 'locked': False}, {'code': ">>> most_stem == 'gener'\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
