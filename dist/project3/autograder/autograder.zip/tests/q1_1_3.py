test = {   'name': 'q1_1_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> type(longest_uncut) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> longest_uncut == 'misunderstand'\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
