test = {   'name': 'q1_2_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 0.15 < outer_space_r < 0.3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(outer_space_r, 3) == .283\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
