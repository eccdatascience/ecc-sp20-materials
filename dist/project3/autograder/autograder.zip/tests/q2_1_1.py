test = {   'name': 'q2_1_1',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> 0 < one_distance < .01\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(one_distance, 6) == .000805\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
