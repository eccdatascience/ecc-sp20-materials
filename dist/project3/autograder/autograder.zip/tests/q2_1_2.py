test = {   'name': 'q2_1_2',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> # Make sure you can use any two movies;\n'
                                               '>>> correct_dis = 0.000541242;\n'
                                               '>>> dis = distance_two_features("clerks.", "the avengers", "water", "feel");\n'
                                               '>>> np.isclose(np.round(dis, 9), correct_dis)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {   'code': '>>> # Make sure you can use any two movies;\n'
                                               '>>> correct_dis = 0.006486728;\n'
                                               '>>> dis = distance_two_features("clerks.", "the avengers", "your", "that");\n'
                                               '>>> np.isclose(np.round(dis, 9), correct_dis)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
