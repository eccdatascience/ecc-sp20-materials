test = {   'name': 'q2_1_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': ">>> np.isclose(distance_from_python('clerks.'), 0.00079838)\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> np.isclose(distance_from_python('the avengers'), 0.0008050869)\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
