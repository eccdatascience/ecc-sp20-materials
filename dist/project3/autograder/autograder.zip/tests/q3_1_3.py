test = {   'name': 'q3_1_3',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> # It looks like you have chosen a illegal option (not within 1 - 5);\n>>> top_right >= 1 and top_right <= 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> top_right == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
