test = {   'name': 'q3_1_4',
    'points': 1,
    'suites': [   {   'cases': [   {'code': '>>> # It looks like you have chosen a illegal option (not within 1 - 5);\n>>> top_left >= 1 and top_left <= 5\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> top_left == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
