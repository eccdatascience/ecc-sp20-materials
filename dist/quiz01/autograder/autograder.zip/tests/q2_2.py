test = {   'name': 'q2_2',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> 1 <= characters_q2 <= 3\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> characters_q2 == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
