test = {   'name': 'q4_2',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> 1 <= jobs_q2 <= 3\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> jobs_q2 == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
