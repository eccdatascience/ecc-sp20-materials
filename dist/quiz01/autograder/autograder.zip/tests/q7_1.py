test = {   'name': 'q7_1',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> 1 <= survivor_answer <= 3\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> survivor_answer == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
