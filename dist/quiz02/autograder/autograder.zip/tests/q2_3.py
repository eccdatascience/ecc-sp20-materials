test = {   'name': 'q2_3',
    'points': None,
    'suites': [{'cases': [{'code': '>>> index_of_last_element == 141\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
