test = {   'name': 'q2_4',
    'points': None,
    'suites': [{'cases': [{'code': '>>> most_recent_birth_year == 1917\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
