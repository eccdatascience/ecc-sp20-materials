test = {   'name': 'q4_1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> largest_population_change == 87515824\nTrue', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
