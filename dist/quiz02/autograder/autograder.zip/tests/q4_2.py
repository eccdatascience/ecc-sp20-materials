test = {   'name': 'q4_2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(cumulative_sum_answer) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 1 <= cumulative_sum_answer <= 3\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> cumulative_sum_answer == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
