test = {   'name': 'q6_4',
    'points': None,
    'suites': [{'cases': [{'code': '>>> sales.sort(0).column(0).item(1) == 26187\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
