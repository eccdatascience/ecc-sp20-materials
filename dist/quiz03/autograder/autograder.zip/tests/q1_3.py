test = {   'name': 'q1_3',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> greatest_nei.take(0).column(0).item(0) == '2009-10-01'\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
