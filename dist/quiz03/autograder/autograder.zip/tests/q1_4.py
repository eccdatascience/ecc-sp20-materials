test = {   'name': 'q1_4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> # It looks like you subtracted in the wrong order.\n>>> round(pter.item(6), 4) != -1.1282\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(pter.item(6), 4) == 1.1282\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
