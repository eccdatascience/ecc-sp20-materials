test = {   'name': 'q1_7',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> highPTER == True or highPTER == False\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> highPTER == True \nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
