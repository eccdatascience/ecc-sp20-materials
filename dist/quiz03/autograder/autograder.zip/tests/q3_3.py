test = {   'name': 'q3_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> # Make sure you assing histogram_column_x to either 1 or 2!\n>>> type(histogram_column_y) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> histogram_column_y == 1 or histogram_column_y == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> histogram_column_y == 1\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
