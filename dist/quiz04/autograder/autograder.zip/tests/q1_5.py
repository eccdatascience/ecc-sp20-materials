test = {   'name': 'q1_5',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(best_restaurant) == str\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> best_restaurant == "Mikes Taco Club"\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
