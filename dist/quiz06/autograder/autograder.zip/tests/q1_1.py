test = {   'name': 'q1_1',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> ten_sixes in [1,2,3]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> ten_sixes == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
