test = {   'name': 'q1_4',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> list_chances in [1,2,3]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> list_chances == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
