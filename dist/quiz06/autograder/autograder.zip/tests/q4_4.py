test = {   'name': 'q4_4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(strongest_earthquake_magnitude, float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(strongest_earthquake_magnitude, 8.0)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
