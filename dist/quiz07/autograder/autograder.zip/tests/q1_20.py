test = {   'name': 'q1_20',
    'points': None,
    'suites': [{'cases': [{'code': '>>> -0.75 <= one_simulated_test_stat <= 0.75\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
