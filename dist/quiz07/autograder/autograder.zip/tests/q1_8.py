test = {   'name': 'q1_8',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> 0 <= p_value < 1\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> observed_val == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
