test = {   'name': 'q2_6',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> 1 <= cutoff_ten_percent <= 3\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> cutoff_ten_percent == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
