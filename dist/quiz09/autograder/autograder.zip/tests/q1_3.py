test = {   'name': 'q1_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(max_estimate) in set([int, np.int32, np.int64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> max_estimate in observations.column(0)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> max_estimate == 135\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
