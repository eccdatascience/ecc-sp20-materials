test = {   'name': 'q4_6',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(sample_mean_sd_statements) == np.ndarray\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(sample_mean_sd_statements) == set([1, 3, 5, 6])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
