test = {   'name': 'q4_7',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(sample_size_calculation) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> sample_size_calculation == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
