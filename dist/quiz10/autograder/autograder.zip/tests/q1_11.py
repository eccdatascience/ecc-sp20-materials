test = {   'name': 'q1_11',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(hela_rnaseq) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.round(hela_rnaseq, 3) == 2.329\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
