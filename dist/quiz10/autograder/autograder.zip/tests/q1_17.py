test = {   'name': 'q1_17',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> type(same_parameters) == bool\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> same_parameters == True\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
