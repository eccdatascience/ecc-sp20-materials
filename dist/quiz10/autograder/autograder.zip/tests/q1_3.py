test = {   'name': 'q1_3',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(highest_correlation) == int\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> highest_correlation == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
