test = {   'name': 'q1_4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> np.isclose(correlation([1,2,3], [4,5,6]), .9999999)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(correlation([-3,0,3], [-3,0,3]), 1.0000000000002)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
