test = {   'name': 'q1_5',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(correlation_change) == bool\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> correlation_change == False\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
