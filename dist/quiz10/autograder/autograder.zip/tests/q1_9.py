test = {   'name': 'q1_9',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> # The returned array should be length 2\n>>> len(parameters_su) == 2\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.allclose(parameters_su, [9.00076475e-01, 1.16123028e-16])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
