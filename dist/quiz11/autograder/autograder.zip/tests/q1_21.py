test = {   'name': 'q1_21',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(clt_applies) == bool and type(residuals_normal) == bool\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> clt_applies == False and residuals_normal == False\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
