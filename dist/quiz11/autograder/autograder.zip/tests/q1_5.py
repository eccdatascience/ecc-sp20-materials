test = {   'name': 'q1_5',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(one_resample) in set([float, np.float32, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.random.seed(19)\n>>> np.round(one_resample_r(nfl, "Pick Number", "Career Length"), 3) == -0.129\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
