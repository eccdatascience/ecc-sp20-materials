test = {   'name': 'q1_3',
    'points': None,
    'suites': [{'cases': [{'code': ">>> sorted(features) == ['latitude', 'longitude']\nTrue", 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
