test = {   'name': 'q1_6',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> # `k` should be an int\n>>> type(k) == int\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> k == 47\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
